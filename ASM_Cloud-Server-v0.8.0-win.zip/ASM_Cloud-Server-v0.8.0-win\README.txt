﻿ASM_Cloud Server v0.8.0 — Windows

1. Install Node.js 20 LTS from https://nodejs.org
2. Copy .env.example to .env and edit (DB, JWT, STORAGE_ROOT)
3. For quick test (no Postgres): set DB_TYPE=sqlite and DB_DATABASE=./data/asm-cloud.db
4. Run: run.bat  (or: npm install && npm run start:prod)
5. Open http://localhost:3000/api/auth/register

See docs/INSTALL_GUIDE.pdf for full layman guide.

