﻿Write-Host 'Starting ASM_Cloud Server...' -ForegroundColor Blue
if (!(Test-Path 'node_modules')) { npm install --legacy-peer-deps }
if (!(Test-Path '.env')) { Copy-Item '.env.example' '.env'; Write-Host 'Created .env — edit it!' -ForegroundColor Yellow }
node dist/main.js
