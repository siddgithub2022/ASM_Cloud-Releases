@echo off
title ASM_Cloud Server
echo Starting ASM_Cloud Server...
if not exist node_modules (
  echo Installing dependencies...
  npm install --legacy-peer-deps
)
if not exist .env (
  copy .env.example .env
  echo Edited .env before next run!
)
node dist/main.js
pause
